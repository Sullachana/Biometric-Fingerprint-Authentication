﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace Attendance_Monitoring_With_Fingerprint
{
    class CsConnection
    {
        public static MySqlConnection connection = null;

        //Connecting and openning the database to the system.
        public static void EstablishConnection()
        {

            try
            {
                string connectionString = string.Format("SERVER={0};USERNAME={1};PASSWORD={2};DATABASE={3};pooling=false;Allow User Variables=True",

                    FetchDatabaseLocation()[0].Trim(), FetchDatabaseLocation()[2].Trim(), FetchDatabaseLocation()[3].Trim(), FetchDatabaseLocation()[4].Trim());
                Console.WriteLine(connectionString);

                connection = new MySqlConnection(connectionString);
                connection.Open();

            }
            catch(Exception){}
        }

        //Read the text file of the system database configuration
        public static string[] FetchDatabaseLocation()
        {
            string[] returnData = new string[5];

            try
            {
                StreamReader file = new StreamReader(Directory.GetCurrentDirectory() + @"\databaseconfig.txt");

                returnData = file.ReadLine().Split('#');
                file.Close();
            }
            catch {}
            return returnData;

        }
    }
}
