﻿namespace Attendance_Monitoring_With_Fingerprint
{
    partial class UsrConLogin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UsrConLogin));
            this.btn_Login = new System.Windows.Forms.Button();
            this.lbl_Invalid = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txt_Username = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btn_Minimize = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.btn_Setting = new System.Windows.Forms.Button();
            this.picBox_Login = new System.Windows.Forms.PictureBox();
            this.lbl_PlaceFinger = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tm_PlaceFinger = new System.Windows.Forms.Timer(this.components);
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Login)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Login
            // 
            this.btn_Login.BackColor = System.Drawing.Color.IndianRed;
            this.btn_Login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Login.FlatAppearance.BorderSize = 0;
            this.btn_Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Login.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Login.ForeColor = System.Drawing.Color.White;
            this.btn_Login.Location = new System.Drawing.Point(282, 442);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(346, 40);
            this.btn_Login.TabIndex = 75;
            this.btn_Login.Text = "LOGIN";
            this.btn_Login.UseVisualStyleBackColor = false;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // lbl_Invalid
            // 
            this.lbl_Invalid.AutoSize = true;
            this.lbl_Invalid.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Invalid.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Invalid.ForeColor = System.Drawing.Color.White;
            this.lbl_Invalid.Location = new System.Drawing.Point(279, 404);
            this.lbl_Invalid.Name = "lbl_Invalid";
            this.lbl_Invalid.Size = new System.Drawing.Size(169, 16);
            this.lbl_Invalid.TabIndex = 73;
            this.lbl_Invalid.Text = "Invalid Password or Username";
            this.lbl_Invalid.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.txt_Password);
            this.panel4.Location = new System.Drawing.Point(312, 368);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(317, 30);
            this.panel4.TabIndex = 71;
            // 
            // txt_Password
            // 
            this.txt_Password.BackColor = System.Drawing.Color.White;
            this.txt_Password.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Password.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Password.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(156)))));
            this.txt_Password.Location = new System.Drawing.Point(5, 6);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.PasswordChar = '•';
            this.txt_Password.Size = new System.Drawing.Size(309, 19);
            this.txt_Password.TabIndex = 0;
            this.txt_Password.TextChanged += new System.EventHandler(this.txt_Password_TextChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox3.Image = global::Attendance_Monitoring_With_Fingerprint.Properties.Resources.icon_password;
            this.pictureBox3.Location = new System.Drawing.Point(282, 368);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(30, 30);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 72;
            this.pictureBox3.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.txt_Username);
            this.panel3.Location = new System.Drawing.Point(312, 325);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(317, 30);
            this.panel3.TabIndex = 69;
            // 
            // txt_Username
            // 
            this.txt_Username.BackColor = System.Drawing.Color.White;
            this.txt_Username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Username.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Username.ForeColor = System.Drawing.Color.DimGray;
            this.txt_Username.Location = new System.Drawing.Point(5, 6);
            this.txt_Username.Name = "txt_Username";
            this.txt_Username.Size = new System.Drawing.Size(309, 19);
            this.txt_Username.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Location = new System.Drawing.Point(282, 325);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 30);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 70;
            this.pictureBox2.TabStop = false;
            // 
            // btn_Minimize
            // 
            this.btn_Minimize.BackColor = System.Drawing.Color.Transparent;
            this.btn_Minimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Minimize.FlatAppearance.BorderSize = 0;
            this.btn_Minimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_Minimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_Minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Minimize.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Minimize.ForeColor = System.Drawing.Color.White;
            this.btn_Minimize.Location = new System.Drawing.Point(859, 43);
            this.btn_Minimize.Name = "btn_Minimize";
            this.btn_Minimize.Size = new System.Drawing.Size(28, 28);
            this.btn_Minimize.TabIndex = 1021;
            this.btn_Minimize.Text = "▬";
            this.btn_Minimize.UseVisualStyleBackColor = false;
            this.btn_Minimize.Click += new System.EventHandler(this.btn_Minimize_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.BackColor = System.Drawing.Color.Transparent;
            this.btn_Close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Close.FlatAppearance.BorderSize = 0;
            this.btn_Close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_Close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Close.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Close.ForeColor = System.Drawing.Color.White;
            this.btn_Close.Location = new System.Drawing.Point(859, 9);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(28, 28);
            this.btn_Close.TabIndex = 1020;
            this.btn_Close.Text = "✘";
            this.btn_Close.UseVisualStyleBackColor = false;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // btn_Setting
            // 
            this.btn_Setting.BackColor = System.Drawing.Color.Transparent;
            this.btn_Setting.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Setting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Setting.FlatAppearance.BorderSize = 0;
            this.btn_Setting.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_Setting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Setting.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Setting.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btn_Setting.Image = global::Attendance_Monitoring_With_Fingerprint.Properties.Resources.icon_database_setting;
            this.btn_Setting.Location = new System.Drawing.Point(862, 563);
            this.btn_Setting.Name = "btn_Setting";
            this.btn_Setting.Size = new System.Drawing.Size(25, 25);
            this.btn_Setting.TabIndex = 1022;
            this.btn_Setting.UseVisualStyleBackColor = false;
            this.btn_Setting.Visible = false;
            this.btn_Setting.Click += new System.EventHandler(this.btn_Setting_Click);
            // 
            // picBox_Login
            // 
            this.picBox_Login.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.picBox_Login.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picBox_Login.Image = ((System.Drawing.Image)(resources.GetObject("picBox_Login.Image")));
            this.picBox_Login.Location = new System.Drawing.Point(377, 132);
            this.picBox_Login.Name = "picBox_Login";
            this.picBox_Login.Size = new System.Drawing.Size(162, 149);
            this.picBox_Login.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_Login.TabIndex = 1024;
            this.picBox_Login.TabStop = false;
            // 
            // lbl_PlaceFinger
            // 
            this.lbl_PlaceFinger.AutoSize = true;
            this.lbl_PlaceFinger.BackColor = System.Drawing.Color.Transparent;
            this.lbl_PlaceFinger.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_PlaceFinger.ForeColor = System.Drawing.Color.White;
            this.lbl_PlaceFinger.Location = new System.Drawing.Point(320, 295);
            this.lbl_PlaceFinger.Name = "lbl_PlaceFinger";
            this.lbl_PlaceFinger.Size = new System.Drawing.Size(291, 17);
            this.lbl_PlaceFinger.TabIndex = 1023;
            this.lbl_PlaceFinger.Text = "P  L  A  C  E       Y  O  U  R        F  I  N  G  E  R";
            this.lbl_PlaceFinger.Visible = false;
            this.lbl_PlaceFinger.Click += new System.EventHandler(this.lbl_PlaceFinger_Click);
            // 
            // tm_PlaceFinger
            // 
            this.tm_PlaceFinger.Enabled = true;
            this.tm_PlaceFinger.Interval = 500;
            this.tm_PlaceFinger.Tick += new System.EventHandler(this.tm_PlaceFinger_Tick);
            // 
            // UsrConLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.BackgroundImage = global::Attendance_Monitoring_With_Fingerprint.Properties.Resources.bg_login;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.picBox_Login);
            this.Controls.Add(this.lbl_PlaceFinger);
            this.Controls.Add(this.btn_Setting);
            this.Controls.Add(this.btn_Minimize);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.lbl_Invalid);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.pictureBox2);
            this.DoubleBuffered = true;
            this.Name = "UsrConLogin";
            this.Size = new System.Drawing.Size(900, 600);
            this.Load += new System.EventHandler(this.UserConLogin_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Login)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Login;
        public System.Windows.Forms.Label lbl_Invalid;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txt_Password;
        public System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txt_Username;
        public System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.Button btn_Minimize;
        public System.Windows.Forms.Button btn_Close;
        public System.Windows.Forms.Button btn_Setting;
        public System.Windows.Forms.PictureBox picBox_Login;
        public System.Windows.Forms.Label lbl_PlaceFinger;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        public System.Windows.Forms.Timer tm_PlaceFinger;
    }
}
